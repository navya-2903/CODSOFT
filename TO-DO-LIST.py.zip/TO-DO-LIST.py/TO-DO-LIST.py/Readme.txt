#this project has been maintained by Vaishnavi Chakraborty
#under the guidance of CodSoft
#project name = To Do List
#Requires One Operator

from tkinter import *
from tkinter import font as tkfont
from PIL import Image, ImageTk
# Initialize the main window
root = Tk()
root.title("TO-DO-LIST")
root.geometry("600x700")
root.resizable(False, False)
task_list = []
# Set window icon
root.iconbitmap(r"c:\Users\Dell\Downloads\Todo.ico")
# Load and set background image
background_image = Image.open(r"c:\Users\Dell\Downloads\BACKGROUND IMAGE.png")
background_image = background_image.resize((600, 700))
background_photo = ImageTk.PhotoImage(background_image)
background_label = Label(root, image=background_photo)
background_label.image = background_photo
background_label.place(x=0, y=0, relwidth=1, relheight=1)
# Load and set top bar image
another_image = Image.open(r"c:\Users\Dell\Downloads\topbar.png")
another_image = another_image.resize((600, 100))
another_photo = ImageTk.PhotoImage(another_image)
another_label = Label(root, image=another_photo)
another_label.image = another_photo
another_label.place(x=0, y=0)
# Load and set doc image
doc = PhotoImage(file=r"c:\Users\Dell\Downloads\dock.png")
Label(root, image=doc, bg="#32405b").place(x=50, y=27)
# Load and set task image
task_img = PhotoImage(file=r"c:\Users\Dell\Downloads\task.png")
Label(root, image=task_img, bg="#32405b").place(x=510, y=20)
# Load the custom font
font_path = r"C:\Users\Dell\Desktop\TKINTER PRACTICE.py\Copyduck.ttf"
doodle_font = tkfont.Font(family='Copyduck', size=24)
label = Label(root, text="YOUR DAILY TASK REMINDER !", font=doodle_font, fg="white", bg="#32405b")
label.place(x=100, y=20)
# Frame for task entry and add button
frame = Frame(root, width=500, height=50, bg="#2F3645")
frame.place(x=40, y=120)
task = StringVar()
taskEntry = Entry(frame, width=15, font=doodle_font, bd=3, textvariable=task)
taskEntry.place(x=5, y=12)
taskEntry.focus()
# Function to refresh the listbox items with numbers
def refreshListbox():
    listbox.delete(0, END)
    for idx, item in enumerate(task_list):
        listbox.insert(END, f"{idx + 1}. {item}")
# Function to add a task
def addTask():
    task_content = task.get()
    if task_content:
        task_list.append(task_content)
        refreshListbox()
        task.set("")
# Function to update a selected task
def updateTask():
    try:
        selected_index = listbox.curselection()[0]
        task_content = task.get()
        if task_content:
            task_list[selected_index] = task_content
            refreshListbox()
            task.set("")
    except IndexError:
        pass
# Function to delete a selected task
def deleteTask():
    try:
        selected_index = listbox.curselection()[0]
        del task_list[selected_index]
        refreshListbox()
    except IndexError:
        pass
button = Button(frame, text="ADD TASK", font="arial 15 bold", bg="#2F3645", fg="white", bd=10, command=addTask)
button.place(x=360, y=0)
update_button = Button(root, text="UPDATE TASK", font="arial 15 bold", bg="#2F3645", fg="white", bd=10, command=updateTask)
update_button.place(x=80, y=600)
delete_image_path = r"c:\Users\Dell\Downloads\delete (2).png"
delete_image = Image.open(delete_image_path)
resized_delete_image = delete_image.resize((50, 50))
delete_task_image = ImageTk.PhotoImage(resized_delete_image)
delete_button = Button(root, image=delete_task_image, bd=10, bg="white", command=deleteTask)
delete_button.image = delete_task_image
delete_button.place(x=310, y=595)
# Frame for the listbox and scrollbar
frame1 = Frame(root, bd=3, width=700, height=280, bg="#0C1844")
frame1.place(x=3, y=190)
listbox_font = tkfont.Font(family='Copyduck', size=16)
listbox = Listbox(frame1, font=listbox_font, width=40, height=16, bg="#2F3645", fg="white", selectbackground="#5a95ff")
listbox.pack(side=LEFT, fill=BOTH, padx=2)
scrollbar = Scrollbar(frame1)
scrollbar.pack(side=RIGHT, fill=BOTH)
listbox.config(yscrollcommand=scrollbar.set)
scrollbar.config(command=listbox.yview)
root.mainloop()